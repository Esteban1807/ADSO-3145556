package com.SENA.FlightManagementSystem.Security.Utils;

public abstract class ABaseUtils {
    // Métodos y atributos comunes para utilidades
}
