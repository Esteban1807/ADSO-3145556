package com.SENA.FlightManagementSystem.Infrastructure.Controller;

public abstract class ABaseController {
    // Métodos y atributos comunes para controladores
}
