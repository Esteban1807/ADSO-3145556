package com.SENA.FlightManagementSystem.Geolocation.Service;

public abstract class ABaseService {
    // Métodos y atributos comunes para servicios
}
