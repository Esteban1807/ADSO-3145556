package com.SENA.FlightManagementSystem.Infrastructure.Utils;

public abstract class ABaseUtils {
    // Métodos y atributos comunes para utilidades
}
