package com.SENA.FlightManagementSystem.Notifications.Service;

public abstract class ABaseService {
    // Métodos y atributos comunes para servicios
}
