package com.SENA.FlightManagementSystem.AircraftManagement.IService;

public interface IBaseService {
    // Métodos comunes para servicios
}
