package com.SENA.FlightManagementSystem.Flight.IRepository;

public interface IBaseRepository {
    // Métodos comunes para repositorios
}
