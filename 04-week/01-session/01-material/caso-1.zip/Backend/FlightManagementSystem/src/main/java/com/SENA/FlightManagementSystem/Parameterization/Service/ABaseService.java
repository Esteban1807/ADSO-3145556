package com.SENA.FlightManagementSystem.Parameterization.Service;

public abstract class ABaseService {
    // Métodos y atributos comunes para servicios
}
