package com.SENA.FlightManagementSystem.Flight.Utils;

public abstract class ABaseUtils {
    // Métodos y atributos comunes para utilidades
}
