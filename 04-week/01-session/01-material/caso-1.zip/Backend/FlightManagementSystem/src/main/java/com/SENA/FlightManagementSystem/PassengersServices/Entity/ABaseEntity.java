package com.SENA.FlightManagementSystem.PassengersServices.Entity;

public abstract class ABaseEntity {
    // Métodos y atributos comunes para entidades
}
