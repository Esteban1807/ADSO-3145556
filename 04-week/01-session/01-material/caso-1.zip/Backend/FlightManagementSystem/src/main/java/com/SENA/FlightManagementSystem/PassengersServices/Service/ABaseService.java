package com.SENA.FlightManagementSystem.PassengersServices.Service;

public abstract class ABaseService {
    // Métodos y atributos comunes para servicios
}
