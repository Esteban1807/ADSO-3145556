package com.SENA.FlightManagementSystem.Geolocation.IService;

public interface IBaseService {
    // Métodos comunes para servicios
}
