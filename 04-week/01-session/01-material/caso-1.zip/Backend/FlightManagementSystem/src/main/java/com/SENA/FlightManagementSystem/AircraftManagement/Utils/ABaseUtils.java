package com.SENA.FlightManagementSystem.AircraftManagement.Utils;

public abstract class ABaseUtils {
    // Métodos y atributos comunes para utilidades
}
