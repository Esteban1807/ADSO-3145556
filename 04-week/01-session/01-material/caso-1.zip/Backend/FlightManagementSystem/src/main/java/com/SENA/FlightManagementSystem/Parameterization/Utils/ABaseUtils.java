package com.SENA.FlightManagementSystem.Parameterization.Utils;

public abstract class ABaseUtils {
    // Métodos y atributos comunes para utilidades
}
