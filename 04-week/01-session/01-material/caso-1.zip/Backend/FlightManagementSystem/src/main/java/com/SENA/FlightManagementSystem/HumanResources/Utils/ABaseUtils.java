package com.SENA.FlightManagementSystem.HumanResources.Utils;

public abstract class ABaseUtils {
    // Métodos y atributos comunes para utilidades
}
