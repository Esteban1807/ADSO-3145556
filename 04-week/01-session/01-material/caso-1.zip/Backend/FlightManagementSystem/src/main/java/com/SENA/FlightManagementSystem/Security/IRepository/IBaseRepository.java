package com.SENA.FlightManagementSystem.Security.IRepository;

public interface IBaseRepository {
    // Métodos comunes para repositorios
}
