package com.SENA.FlightManagementSystem.Parameterization.Controller;

public abstract class ABaseController {
    // Métodos y atributos comunes para controladores
}
