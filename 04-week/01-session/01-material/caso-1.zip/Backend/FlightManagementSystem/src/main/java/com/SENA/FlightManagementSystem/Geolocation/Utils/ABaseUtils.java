package com.SENA.FlightManagementSystem.Geolocation.Utils;

public abstract class ABaseUtils {
    // Métodos y atributos comunes para utilidades
}
