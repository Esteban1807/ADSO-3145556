package com.SENA.FlightManagementSystem.Notifications.Utils;

public abstract class ABaseUtils {
    // Métodos y atributos comunes para utilidades
}
