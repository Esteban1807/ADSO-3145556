package com.SENA.FlightManagementSystem.Infrastructure.IService;

public interface IBaseService {
    // Métodos comunes para servicios
}
