package com.SENA.FlightManagementSystem.Flight.Controller;

public abstract class ABaseController {
    // Métodos y atributos comunes para controladores
}
