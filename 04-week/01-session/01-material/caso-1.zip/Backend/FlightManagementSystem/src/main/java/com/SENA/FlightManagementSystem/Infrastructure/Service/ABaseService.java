package com.SENA.FlightManagementSystem.Infrastructure.Service;

public abstract class ABaseService {
    // Métodos y atributos comunes para servicios
}
