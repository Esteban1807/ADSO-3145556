package com.SENA.FlightManagementSystem.AircraftManagement.Controller;

public abstract class ABaseController {
    // Métodos y atributos comunes para controladores
}
