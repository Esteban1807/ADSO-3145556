package com.SENA.FlightManagementSystem.PassengersServices.IRepository;

public interface IBaseRepository {
    // Métodos comunes para repositorios
}
