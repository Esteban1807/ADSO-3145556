package com.SENA.FlightManagementSystem.AircraftManagement.IRepository;

public interface IBaseRepository {
    // Métodos comunes para repositorios
}
